--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.3
-- Dumped by pg_dump version 9.5.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.victimas DROP CONSTRAINT victimas_id_victima_fkey;
ALTER TABLE ONLY public.acusados DROP CONSTRAINT acusados_id_acusado_fkey;
ALTER TABLE ONLY public.hechos DROP CONSTRAINT id_pk;
DROP TABLE public.victimas;
DROP TABLE public.hechos;
DROP TABLE public.acusados;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: da_prueba; Type: COMMENT; Schema: -; Owner: ivan
--

COMMENT ON DATABASE da_prueba IS 'DB de prueba para separación de tablas de DA';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: acusados; Type: TABLE; Schema: public; Owner: ivan
--

CREATE TABLE acusados (
    id_acusado integer,
    rol character varying(50),
    tipo character varying(150),
    marca character varying(50),
    modelo character varying(50),
    colectivo character varying(25),
    interno_colectivo character varying(25),
    sexo character varying(25),
    edad integer,
    repetido integer
);


ALTER TABLE acusados OWNER TO ivan;

--
-- Name: hechos; Type: TABLE; Schema: public; Owner: ivan
--

CREATE TABLE hechos (
    orden integer,
    id integer NOT NULL,
    fuente character varying(25),
    periodo character varying(25),
    comisaria character varying(5),
    fecha date,
    hora time without time zone,
    tipo_colision character varying(100),
    tipo_hecho character varying(25),
    lugar_hecho character varying(200),
    direccion_normalizada character varying(200),
    tipo_calle character varying(50),
    direccion_normalizada_arcgis character varying(200),
    calle1 character varying(100),
    altura integer,
    calle2 character varying(100),
    codigo_calle integer,
    codigo_cruce integer,
    geocodificacion character varying(300),
    franja_horaria integer,
    dia_semana character varying(25),
    semestre integer,
    repetido integer,
    franja_etaria_acusado integer,
    franja_etaria_victima integer
);


ALTER TABLE hechos OWNER TO ivan;

--
-- Name: victimas; Type: TABLE; Schema: public; Owner: ivan
--

CREATE TABLE victimas (
    id_victima integer,
    causa character varying(50),
    rol character varying(50),
    tipo character varying(150),
    marca character varying(50),
    modelo character varying(50),
    colectivo character varying(25),
    interno_colectivo character varying(25),
    sexo character varying(25),
    edad integer,
    sumario integer,
    repetido integer
);


ALTER TABLE victimas OWNER TO ivan;

--
-- Data for Name: acusados; Type: TABLE DATA; Schema: public; Owner: ivan
--

COPY acusados (id_acusado, rol, tipo, marca, modelo, colectivo, interno_colectivo, sexo, edad, repetido) FROM stdin;
\.
COPY acusados (id_acusado, rol, tipo, marca, modelo, colectivo, interno_colectivo, sexo, edad, repetido) FROM '$$PATH$$/2146.dat';

--
-- Data for Name: hechos; Type: TABLE DATA; Schema: public; Owner: ivan
--

COPY hechos (orden, id, fuente, periodo, comisaria, fecha, hora, tipo_colision, tipo_hecho, lugar_hecho, direccion_normalizada, tipo_calle, direccion_normalizada_arcgis, calle1, altura, calle2, codigo_calle, codigo_cruce, geocodificacion, franja_horaria, dia_semana, semestre, repetido, franja_etaria_acusado, franja_etaria_victima) FROM stdin;
\.
COPY hechos (orden, id, fuente, periodo, comisaria, fecha, hora, tipo_colision, tipo_hecho, lugar_hecho, direccion_normalizada, tipo_calle, direccion_normalizada_arcgis, calle1, altura, calle2, codigo_calle, codigo_cruce, geocodificacion, franja_horaria, dia_semana, semestre, repetido, franja_etaria_acusado, franja_etaria_victima) FROM '$$PATH$$/2144.dat';

--
-- Data for Name: victimas; Type: TABLE DATA; Schema: public; Owner: ivan
--

COPY victimas (id_victima, causa, rol, tipo, marca, modelo, colectivo, interno_colectivo, sexo, edad, sumario, repetido) FROM stdin;
\.
COPY victimas (id_victima, causa, rol, tipo, marca, modelo, colectivo, interno_colectivo, sexo, edad, sumario, repetido) FROM '$$PATH$$/2145.dat';

--
-- Name: id_pk; Type: CONSTRAINT; Schema: public; Owner: ivan
--

ALTER TABLE ONLY hechos
    ADD CONSTRAINT id_pk PRIMARY KEY (id);


--
-- Name: acusados_id_acusado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ivan
--

ALTER TABLE ONLY acusados
    ADD CONSTRAINT acusados_id_acusado_fkey FOREIGN KEY (id_acusado) REFERENCES hechos(id);


--
-- Name: victimas_id_victima_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ivan
--

ALTER TABLE ONLY victimas
    ADD CONSTRAINT victimas_id_victima_fkey FOREIGN KEY (id_victima) REFERENCES hechos(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

